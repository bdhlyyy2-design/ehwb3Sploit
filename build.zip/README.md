<h1 align="center">
  <br>
  <a href="https://github.com/HathemAhmed/MikrotikSploit"><img src="https://www.charbase.com/images/glyph/9763" alt="MikrotikSploit"></a>
  <br>
  MikrotikSploit
  <br>
</h1>

<h4 align="center">MikrotikSploit is a script that searches for and exploits Mikrotik network vulnerabilities</h4>


![Screenshot from 2026-08-6 05-22-04](https://raw.githubusercontent.com/HathemAhmed/MikrotikSploit/master/modules/images/b1.png)



**MikrotikSploit**  is a script that searches for and exploits Mikrotik network vulnerabilities Loophole pull numbers of network login cards ... 
Loophole know the username and password of the admin panel of the network Mikrotik ... A special section of the DoS system


-------------------------------------

### _☣ Features_

- Checks for vulnerabilities
- Integrated guess system on login cards
- Discover the name and password of the network management panel
- DDoS attack
- find the mistakes and resolve it
- Reporting: simple, Text.

-------------------------------------

### _☣ Available command line options_
[`READ MikrotikSploi WIKI`](https://github.com/HathemAhmed/MikrotikSploit/wiki)

    usage: MikrotikSploit [options]
    
     [ 1 ] Getting Password    | Getting Password Cards Page Login My Network
     [ 2 ] Hack Mikrotik Panel | Exploit Mikrotik Admin Panel
     [ 3 ] DoDs Network        | DoDs for Your NetWork
     [ 4 ] About Us            | My Information 
     [ 5 ] Exit                | Logout in This Script


-------------------------------------

### _☣ Docker_

تخمين كروت شبكات من اروع الادوات الاوامر دفعه وحده !!.

```bash
 git clone https://github.com/ehwb3Sploit/MikrotikSploit.git
 cd MikrotikSploit
 python3 -m pip install -r requirements.txt
 python3 MikrotikSploit.py
```

-------------------------------------


```BASH
 pkg update
 pkg install -y git
 git clone https://github.com/ehwb3Sploit/MikrotikSploit.git
 cd MikrotikSploit
 chmod +x setup.py
 ./setup.py install
 python3 -m pip install -r requirements.txt
 python3 MikrotikSploit.py
```

*************************************************************
تعديل ابن اليمن https://t.me/Aehabbb

*************************************************************